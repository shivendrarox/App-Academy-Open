# Write a method, all_vowel_pairs, that takes in an array of words and returns all pairs of words
# that contain every vowel. Vowels are the letters a, e, i, o, u. A pair should have its two words
# in the same order as the original array. 
#
# Example:
#
# all_vowel_pairs(["goat", "action", "tear", "impromptu", "tired", "europe"])   # => ["action europe", "tear impromptu"]
def all_vowel_pairs(words)
    hash=Hash.new({})
    words.each do |ele|
        hash[ele]=[]
        ele.chars.each do |c|
            if c.match?(/[aeiou]/)
                if !hash[ele].include?(c)
                    hash[ele]<<c
                end
            end
        end
    end
    #p hash
    arr=[]
    hash.each_pair do |key,value|
        hash.each_pair do |key2,value2|
            v=value+value2
            v.uniq!
            if v.sort=="aeiou".chars
                arr<<key+" "+key2
                
            end
        end
    end
    #p arr
    arr.each.with_index do |e1,i1|
        arr.each.with_index do |e2,i2|
            if e1.split(" ")==e2.split(" ").reverse
                arr.delete_at(i2)
            end
        end
    end

    arr
end


# Write a method, composite?, that takes in a number and returns a boolean indicating if the number
# has factors besides 1 and itself
#
# Example:
#
# composite?(9)     # => true
# composite?(13)    # => false
def composite?(num)
    x=2
    while x<num
        return true if num % x == 0
        x+=1
    end
    return false
end


# A bigram is a string containing two letters.
# Write a method, find_bigrams, that takes in a string and an array of bigrams.
# The method should return an array containing all bigrams found in the string.
# The found bigrams should be returned in the the order they appear in the original array.
#
# Examples:
#
# find_bigrams("the theater is empty", ["cy", "em", "ty", "ea", "oo"])  # => ["em", "ty", "ea"]
# find_bigrams("to the moon and back", ["ck", "oo", "ha", "at"])        # => ["ck", "oo"]
def find_bigrams(str, bigrams)
    str=str.split(' ')
    arr=[]
        bigrams.each do |b|
            str.each do |word|
                if word.include?(b)
                    arr<<b
                end
            end
        end
    arr

end

class Hash
    # Write a method, Hash#my_select, that takes in an optional proc argument
    # The method should return a new hash containing the key-value pairs that return
    # true when passed into the proc.
    # If no proc is given, then return a new hash containing the pairs where the key is equal to the value.
    #
    # Examples:
    #
    # hash_1 = {x: 7, y: 1, z: 8}
    # hash_1.my_select { |k, v| v.odd? }          # => {x: 7, y: 1}
    #
    # hash_2 = {4=>4, 10=>11, 12=>3, 5=>6, 7=>8}
    # hash_2.my_select { |k, v| k + 1 == v }      # => {10=>11, 5=>6, 7=>8})
    # hash_2.my_select                            # => {4=>4}
    def my_select(&prc)

        hash=Hash.new({})

        if prc==nil
            self.each_pair do |key,value|
                if key==value
                    hash[key]=value
                end
            end
            return hash
        end

        self.each_pair do |key,value|
            if prc.call(key,value)==true
                hash[key]=value
            end
        end
       hash
    end
end

class String
    # Write a method, String#substrings, that takes in a optional length argument
    # The method should return an array of the substrings that have the given length.
    # If no length is given, return all substrings.
    #
    # Examples:
    #
    # "cats".substrings     # => ["c", "ca", "cat", "cats", "a", "at", "ats", "t", "ts", "s"]
    # "cats".substrings(2)  # => ["ca", "at", "ts"]
    def substrings(length = nil)
        arr=self.chars
        x=0
        n_arr=[]
        if length==nil
           arr.each.with_index do |ele,i|
                x=0
                while x<arr.length
                    if arr[i..x].join != ""
                        n_arr<<arr[i..x].join
                    end
                    x+=1
                end
           end
           return n_arr    
        end
        while x<arr.length
            if self.slice(x,length).length==length
                n_arr<<self.slice(x,length)
            end
            x+=1
        end
        n_arr
    end


    # Write a method, String#caesar_cipher, that takes in an a number.
    # The method should return a new string where each char of the original string is shifted
    # the given number of times in the alphabet.
    #
    # Examples:
    #
    # "apple".caesar_cipher(1)    #=> "bqqmf"
    # "bootcamp".caesar_cipher(2) #=> "dqqvecor"
    # "zebra".caesar_cipher(4)    #=> "difve"
    def caesar_cipher(num)
        arr=self.chars
        og_length=arr.length
        x=0
        while x<num
            arr.each do |ele|
                
                    ele.next!
                
            end
            x+=1
        end
       
        
        if arr.join.length>og_length
            ind=arr.join.length-og_length
            arr=arr.join
            arr=arr.chars
            return arr.join[ind..-1]
        else
            arr.join
        end
    end
end
