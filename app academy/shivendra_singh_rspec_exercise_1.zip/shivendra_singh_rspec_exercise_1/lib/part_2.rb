def hipsterfy(word)
    if !(word.instance_of?(String))
        raise "Args must be string"
    end
    vowel="aeiou".chars

    word=word.chars

    char=""
    word.each_with_index{ |w,i|
        vowel.each{|v|
    if w==v
        char=i
        break
    end
    }
    }
    if char==""
        return word.join
    end
    word.delete_at(char)
   return word.join
end

def vowel_counts(str)
    if !(str.instance_of?(String))
        raise "must be a string"
    end

    str=str.downcase.chars
    hash=Hash.new()
    vowel="aeiou".chars 
    sum=0   


        vowel.each do |v|
            sum=0
            str.each_with_index do |x,i|

                if v==x
                    hash[x]=sum+=1
                end
            end
        end

    return hash
end

def caesar_cipher(msg,n)
    if !(msg.instance_of?(String) and n.instance_of?(Integer))
        raise "must be a string and an integer"
    end

    msg=msg.chars
    msg_len=msg.length
    n.times{
    msg.map! do |x|
        if /[[:alpha:]]/.match?(x)
            if x.succ.chars.length>=2
                x=x.succ[-1]
            else
                x=x.succ
            end
        else
            x=x
        end
      
    end
    }

  return msg.join

end

p caesar_cipher("##@", 52)