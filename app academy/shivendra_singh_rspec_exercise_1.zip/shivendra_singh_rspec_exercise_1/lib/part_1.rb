def average(a,b)
    if !(a.instance_of?(Integer) && b.instance_of?(Integer))
        raise "arguments must be integers"
      end
      return (a+b)/2.0
end

def average_array(arr)
    if !(arr.instance_of?(Array))
        raise "arguments must be Array"
      end
      sum=0
      arr.each do |a|
        sum+=a
      end

      return sum/arr.length.to_f
end

def repeat(str,num)
    if !(str.instance_of?(String) && num.instance_of?(Integer))
        raise "arguments must be a string and an integer"
      end
      return str*num
end

def yell(str)
    if !(str.instance_of?(String))
        raise "arguments must be string"
      end
      str.chars.map{|s| s.upcase}.join<<"!"
end

def alternating_case(str)
    if !(str.instance_of?(String))
        raise "arguments must be string"
      end

      str=str.split
      upcaseAtBeginning=false
      if str[0]==str[0].upcase
        upcaseAtBeginning=true
      end

      if !upcaseAtBeginning
        str.each_with_index do |x,i|
          if i.even?
            str[i]=str[i].swapcase
           end
        end
      end

      if upcaseAtBeginning
        str.each_with_index do |x,i|
          if i.odd?
            str[i]=str[i].swapcase
           end
        end
      end

     return str.join(" ")
end

