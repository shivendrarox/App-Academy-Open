class Board
    def initialize(n)
        @grid = Array.new(n){Array.new(n,'_')}
    end

    def valid?(position)
        if position[0] >= @grid.length or position[0] < 0
            return false
        end
        if position[1] >= @grid.length or position[1] < 0
            return false
        end
        return true
    end

    def empty?(position)
        if @grid[position[0]][position[1]] != '_'
            return false
        else
            return true
        end
    end

    def place_mark(position,mark)
        if valid?(position) and empty?(position)
            @grid[position[0]][position[1]] = mark
        else
            raise "invalid position or not an empty spot"
        end
    end

    def print
        @grid.each do |row|
            puts row.to_s+"\n"
        end
    end

    def win_row?(mark)
        @grid.each do |row|
            if row.count(mark) == row.length
                return true
            end
        end
        return false
    end

    def win_col?(mark)
        arr = []
        #return false
        @grid[0].each.with_index do |ele,ei|
            arr=[]
            if ele == mark
                @grid[1..-1].each.with_index do |row,ri|
                    if @grid[ri-1][ei] == @grid[ri][ei]
                        arr<<mark
                    end
                end
            end
            #p arr
            if arr.count(mark) == @grid.length-1
                return true
            end
        end
      return false
    end

    def win_diagonal?(mark)
        if mark  == @grid[0][0] and mark == @grid[-1][-1]
            (0...@grid.length).each do |ele|
                if @grid[ele][ele] != mark
                    return false
                end
            end
        else #mark == @grid[0][-1]
            grid_r = []
            @grid.each do |ele|
                grid_r<<ele.reverse
            end
            (0...@grid.length).each do |ele|
                if grid_r[ele][ele] != mark
                    return false
                end
            end
        end
        return true
    end

    def win?(mark)
        if win_row?(mark) or win_col?(mark) or win_diagonal?(mark)
            return true
        else
            return false
        end
    end

    def empty_positions?
        c=0
        @grid.each do |ele|
            c+=ele.count('_')
        end
        if c>=1
            return true
        else
            return false
        end
    end

    def legal_positions
        arr = []
            @grid.each.with_index do |row,ri|
                row.each.with_index do |ele,ei|
                    r=ri
                    c=ei
                    if empty?([r,c])
                        arr<<[r,c]
                    end
                end
            end
        return arr
    end
end