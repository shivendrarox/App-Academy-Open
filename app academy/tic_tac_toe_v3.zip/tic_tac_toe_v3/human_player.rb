class HumanPlayer
    def initialize(mark_value)
        @mark = mark_value
    end

    def mark
        @mark
    end

    def get_position(legal_positions)
        x=""
        arr = []
        while true
            x=""
            arr = []
            puts "Player "+mark.to_s+", Pls enter a position in this format Number<space>Number"
            x=gets.chomp
            #p x
            if x.match?(/\A\d*\s\d*\z/)
                x.split(' ').each do |ele|
                    arr<<ele.to_i
                end
                if legal_positions.include?(arr)
                    break
                end
            end
            
            puts "Incorrect format or out of bounds :-(,pls enter again"
        end
        
        return arr
    end
end