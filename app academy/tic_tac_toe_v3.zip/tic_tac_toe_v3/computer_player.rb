
class ComputerPlayer
    def initialize(mark_value)
        @mark = mark_value
    end

    def mark
        @mark
    end

    def get_position(legal_positions)
        random_choice = legal_positions.sample
        puts "Computer "+mark.to_s+" chose position "+random_choice.to_s
        return random_choice
    end
end