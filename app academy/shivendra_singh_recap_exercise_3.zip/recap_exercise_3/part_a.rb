def no_dupes?(arr)
    hash=Hash.new(0)
    n_arr=[]
    arr.each.with_index do |ele,ind|
        hash[ele]=hash[ele]+1
    end

    hash.each_pair do |key,val|
        if val==1
            n_arr<<key
        end
    end

    
    p n_arr
end

no_dupes?(['x', 'x', 'y', 'z', 'z'])        # => ['y']
no_dupes?([1, 1, 2, 1, 3, 2, 4])           # => [3,4]
no_dupes?([true, true, true])            # => []

def no_consecutive_repeats?(arr)
    x=0
    while x<arr.length
        if arr[x]==arr[x+1]
            return false
        end
        x+=1
    end
    return true
end

p no_consecutive_repeats?(['cat', 'dog', 'mouse', 'dog'])     # => true
p no_consecutive_repeats?(['cat', 'dog', 'dog', 'mouse'])     # => false
p no_consecutive_repeats?([10, 42, 3, 7, 10, 3])              # => true
p no_consecutive_repeats?([10, 42, 3, 3, 10, 3])              # => false
p no_consecutive_repeats?(['x'])                              # => true

def char_indices(str)
    hash=Hash.new([])
    str.chars.each do |ele|
        hash[ele]=[]
    end
    str.chars.each.with_index do |ele,i|
        hash[ele]<<i
    end
    hash
end

p char_indices('mississippi')   # => {"m"=>[0], "i"=>[1, 4, 7, 10], "s"=>[2, 3, 5, 6], "p"=>[8, 9]}
p char_indices('classroom')     # => {"c"=>[0], "l"=>[1], "a"=>[2], "s"=>[3, 4], "r"=>[5], "o"=>[6, 7], "m"=>[8]}


def longest_streak(str)
    hash=Hash.new('')
    
    str.chars.each.with_index do |ele,i|
        hash[ele]+=ele
    end
    hash.values.max{|a,b| 
        if (a.length <=> b.length )== 0
            1
        else
            a.length <=> b.length
        end
    }
   
end

p longest_streak('a')           # => 'a'
p longest_streak('accccbbb')    # => 'cccc'
p longest_streak('aaaxyyyyyzz') # => 'yyyyy
p longest_streak('aaabbb')      # => 'bbb'
p longest_streak('abc')         # => 'c'


def is_prime?(num)
    flag=true
    (2...num).each do |ele|
        if num%ele==0
            flag = false
        end
    end
    return flag
end


def bi_prime?(num)
    flag=false
    (2..num).each do |ele1|
        if is_prime?(ele1)
            (2..num).each do |ele2|
                if is_prime?(ele2)
                    if ele1*ele2==num
                        flag=true
                    end
                end
            end
        end
    end
    flag
end

p bi_prime?(14)   # => true
p bi_prime?(22)   # => true
p bi_prime?(25)   # => true
p bi_prime?(94)   # => true
p bi_prime?(24)   # => false
p bi_prime?(64)   # => false

def vigenere_cipher(message,keys)
    message_arr=message.chars
    
    keys.each.with_index do |k,i|
       ith_elements(i,keys.length,message_arr.length).each do |ele|
        message_arr[ele]=next_by(message_arr[ele],k)
       end
    end
    message_arr.delete(nil)
    p message_arr.join
end

def ith_elements(start,gap,max)
    arr=[start]
    (start..max).each do |ele|
        if arr[-1]+gap >max
            break
        end
        arr<<arr[-1]+gap
    end
    arr
end


def next_by(chr,num)
    out_chr=chr
    (1..num).each do |ele|
        if out_chr.is_a?(NilClass)
            break
        end
        out_chr=out_chr.succ[-1]
    end
    out_chr
end

vigenere_cipher("toerrishuman", [1])        # => "upfssjtivnbo"
vigenere_cipher("toerrishuman", [1, 2])     # => "uqftsktjvobp"
vigenere_cipher("toerrishuman", [1, 2, 3])  # => "uqhstltjxncq"
vigenere_cipher("zebra", [3, 0])            # => "ceerd"
vigenere_cipher("yawn", [5, 1])             # => "dbbo"

def vowel_rotate(str)
    str_arr=str.chars
    vowels=['a','e','i','o','u']
    vowels_at=[]
    vowels_found=[]
    str_arr.each.with_index do |ele,ind|
        vowels.each.with_index do |v, vi|
            if v==ele
                vowels_found<<ele
                vowels_at<<ind
            end
        end
    end

    vowels_found.unshift(vowels_found.pop)
    vowels_at.each do |ind|
        str_arr[ind]=vowels_found[0]
        vowels_found.shift
    end
    p str_arr.join
end

vowel_rotate('computer')      # => "cempotur"
vowel_rotate('oranges')       # => "erongas"
vowel_rotate('headphones')    # => "heedphanos"
vowel_rotate('bootcamp')      # => "baotcomp"
vowel_rotate('awesome')       # => "ewasemo"