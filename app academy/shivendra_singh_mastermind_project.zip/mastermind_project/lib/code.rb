class Code
  POSSIBLE_PEGS = {
    "R" => :red,
    "G" => :green,
    "B" => :blue,
    "Y" => :yellow
  }
  def self.valid_pegs?(chars)
    isMatch=true
    chars.each do |ele|
      if !POSSIBLE_PEGS.has_key?(ele.upcase)
        isMatch=false
        break
      end
    end
    return isMatch
  end

  def initialize(chars)
    if Code.valid_pegs?(chars)
      @pegs=chars.map{|ele| ele.upcase}
    else
      raise "error"
    end
  end

  def pegs
    @pegs
  end

  def self.random(len)
    chars=Array.new(len)
    chars.fill{|i| i=POSSIBLE_PEGS.keys.sample()}
    new_code=Code.new(chars)
    return new_code
  end

  def self.from_string(str)
    new_code=Code.new(str.chars)
    return new_code
  end
  
  def [](ind)
    self.pegs[ind]
  end

  def length
    return self.pegs.length
  end

  def num_exact_matches(code_guess)
    nums=0
    code_guess.pegs.each_with_index do |ele,i|
      self.pegs.each_with_index do |self_ele,self_i|
        if self_ele==ele and self_i==i
          nums+=1
        end
      end
    end
    return nums
  end

  def num_near_matches(code_guess)
    nums=0
    code_guess.pegs.each_with_index do |ele,i|
        if self.pegs.include?(ele)
          nums+=1
        end
    end
    return nums-(self.num_exact_matches(code_guess))
  end

  def ==(new_code)
    self.pegs.eql?(new_code.pegs)
  end



  

end
