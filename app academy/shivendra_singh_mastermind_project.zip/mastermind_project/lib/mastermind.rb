require_relative "code"

class Mastermind
    def initialize(length)
       @secret_code = Code.random(length)
    end

    def secret_code
        @secret_code
    end

    def print_matches(new_code)
        p self.secret_code.num_exact_matches(new_code)
        p self.secret_code.num_near_matches(new_code)
    end

    def ask_user_for_guess
        p 'Enter a code'
        input=gets.chomp
        new_code=Code.from_string(input)
        print_matches(new_code)
        return self.secret_code==new_code
    end
end
