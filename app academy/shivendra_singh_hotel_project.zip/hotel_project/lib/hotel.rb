require_relative "room"

class Hotel
  def initialize(name,hash)
        @name=name
        @rooms=Hash.new()
        hash.each_pair do |key,value|
            @rooms[key]=Room.new(value)
        end
  end

    def name
        @name.split.each{|x| x.capitalize!}.join(" ")
    end

    def rooms
        @rooms
    end

    def room_exists?(name)
        if @rooms.has_key?(name)
            return true
        else
            return false
        end
    end

    def check_in(person,room)
        if self.room_exists?(room)
                 if  @rooms[room].add_occupant(person)
                    print 'check in successful'
                 else
                    print 'sorry, room is full'
                 end
           
        else
            print 'sorry, room does not exist'
        end
    end

    def has_vacancy?
        @rooms.each_pair do |k,v|
            if !(@rooms[k].available_space==0)
                return true
            end
        end
        return false
    end

    def list_rooms
        @rooms.each_pair do |k,v|
            print k+".*"+@rooms[k].available_space.to_s+"\n"
        end
    end

end