def palindrome?(str)
    str=str.chars
    arr=[]
    str.each do |s|
        arr.unshift(s)
    end
    return true if arr.join==str.join
    return false
end

palindrome?("racecar")

def substrings(str)

    if !(str.instance_of?(String))
        raise "improper args"
    end

    n_arr=[]
    str=str.chars
    str.each_with_index do |s,i|
        (i...str.length).each do |x|
            n_arr<<str[i..x].join
        end
    end
   
     return n_arr
end


def palindrome_substrings(str)

    if !(str.instance_of?(String))
        raise "improper args"
    end

    n_arr=[]
    res=substrings(str)
    

    res.each do |r|
        if palindrome?(r) and r.length>1
            n_arr<<r
        end
    end

    return n_arr
end

p palindrome_substrings("abracadabra")