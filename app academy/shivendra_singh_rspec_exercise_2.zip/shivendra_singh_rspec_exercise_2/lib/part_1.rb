def partition(arr,n)
    if !(arr.instance_of?(Array) && n.instance_of?(Integer))
        raise "improper args"
    end

    larr=[]
    rarr=[]

    arr.each do |x|
        if x>=n
            rarr<<x
        else
            larr<<x
        end

    end

    return [larr,rarr]
end

def merge(h1,h2)
    if !(h1.instance_of?(Hash) and h2.instance_of?(Hash))
        raise "imprper args"
    end

    hash=Hash.new()
    h1.each{
        |k1,v1|
        hash[k1]=v1
        h2.each{
            |k2,v2|
            hash[k2]=v2
        }
    }
    return hash
end

def censor(str,arr)
    if !(str.instance_of?(String) and arr.instance_of?(Array))
        raise "impoper args"
    end
    str=str.split
    ind=[]

    str.each_with_index do |s,si|
        arr.each_with_index do |e,i|
            if s.downcase==e
                ind<<si
            end
        end
    end


    ind.each do |i|
        str[i]=str[i].tr('aeiouAEIOU', '*')
    end

    return str.join(" ")
    
end

p censor("Gosh darn it", ["gosh", "darn", "shoot"])
p censor("SHUT THE FRONT DOOR", ["door"])

def power_of_two?(n)
    if !(n.instance_of?(Integer))
        raise "improper args"
    end

    isPower=false
    x=0
    while x<=n
        if 2**x==n
            isPower=true
            break
        end
        if 2**x>n
            break
        end
        x=x+1
    end

    return isPower
end

p power_of_two?(100)