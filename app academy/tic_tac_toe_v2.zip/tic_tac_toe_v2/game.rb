require_relative 'board'
require_relative 'human_player'
class Game
    def initialize(n,*players_mark)
        @players_mark = players_mark
        @board = Board.new(n)
        @players = []
       # @new_player = HumanPlayer.new(player_1_mark)
       # @new_player2 = HumanPlayer.new(player_2_mark)
       @players_mark.each do |ele|
            @players << HumanPlayer.new(ele)
       end
        @current_player = @players[0]
    end

    def switch_turn
        if @current_player == @players[0]
            @players.rotate!
            @current_player = @players[0]
        end
    end

    def play
        while @board.empty_positions?
            pos=[]
            @board.print()
            
            pos = @current_player.get_position
            @board.place_mark(pos,@current_player.mark)
            
            
            if @board.win?(@current_player.mark)
                @board.print
                puts @current_player.mark.to_s+" has won!!"
                return
            else
                switch_turn()
            end
        
        end
        
        
            puts "Draw, u all are losers"
        
    end
end