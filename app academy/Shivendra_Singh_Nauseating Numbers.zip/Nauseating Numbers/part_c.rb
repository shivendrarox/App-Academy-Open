def matrix_addition_reloaded(*arr)
    if arr.length == 1
        return arr[0]
    elsif arr.max {|a,b| a.length <=> b.length} != arr.min {|a,b|a.length <=> b.length}
        return nil
    end
    sum01=matrix_addition(arr.shift,arr.shift)
    x=0
    while arr.length != 0
        sum01=matrix_addition(sum01,arr.shift)
        x+=1
    end
    sum01
end

def matrix_addition(matrix1,matrix2)
    fl_mat1=matrix1.flatten
    fl_mat2=matrix2.flatten
   
    fl_sum = []
    empty_table = Array.new(matrix1.length)


    fl_mat1.each.with_index do |e1,i1|
        fl_mat2.each.with_index do |e2,i2|
            if i1 == i2
                fl_sum << (e1+e2)
            end
        end
    end 

    
    empty_table.each.with_index do |ele,i|
        empty_table[i] = fl_sum[0..1]
        fl_sum.shift
        fl_sum.shift
    end
    empty_table
end


matrix_a = [[2,5], [4,7]]
matrix_b = [[9,1], [3,0]]
matrix_c = [[-1,0], [0,-1]]
matrix_d = [[2, -5], [7, 10], [0, 1]]
matrix_e = [[0 , 0], [12, 4], [6,  3]]


p matrix_addition_reloaded(matrix_a, matrix_b)              # [[11, 6], [7, 7]]
p matrix_addition_reloaded(matrix_a, matrix_b, matrix_c)    # [[10, 6], [7, 6]]
p matrix_addition_reloaded(matrix_e)                        # [[0, 0], [12, 4], [6, 3]]
p matrix_addition_reloaded(matrix_d, matrix_e)              # [[2, -5], [19, 14], [6, 4]]
p matrix_addition_reloaded(matrix_a, matrix_b, matrix_e)    # nil
p matrix_addition_reloaded(matrix_d, matrix_e, matrix_c)    # nil
p "--------------------------------------------------------------"

def squarocol?(arr)
    arr.each do |row|
        if row.uniq[0] == row[-1] and row.uniq.length == 1
            return true
        end
    end
    hash = Hash.new([])

    arr.each do |row|
        row.each.with_index do |ele,i|
            hash[ele]=[]
        end
    end

    arr[0].each.with_index do |c,ci|
        x=0
        is_equal=[]
        while x<arr.length
            if c == arr[x][ci]
                is_equal<<true
            end
            x+=1
        end
           
        if is_equal.count(true) == arr.length
            return true
        end
    end
    return false
end

p squarocol?([
    [:a, :x , :d],
    [:b, :x , :e],
    [:c, :x , :f],
]) # true

p squarocol?([
    [:x, :y, :x],
    [:x, :z, :x],
    [:o, :o, :o],
]) # true

p squarocol?([
    [:o, :x , :o],
    [:x, :o , :x],
    [:o, :x , :o],
]) # false

p squarocol?([
    [1, 2, 2, 7],
    [1, 6, 6, 7],
    [0, 5, 2, 7],
    [4, 2, 9, 7],
]) # true

p squarocol?([
    [1, 2, 2, 7],
    [1, 6, 6, 0],
    [0, 5, 2, 7],
    [4, 2, 9, 7],
]) # false

p "----------------------------------------------------------"

def squaragonal?(arr)
    

    arr.each do |row|
        row.each.with_index do |ele,i|
            #hash[ele]=[]
        end
    end

    arr[0].each.with_index do |c,ci|
        x=0
        is_equal=[]
        while x<arr.length
            x+=1

            if x<arr.length and (ci+x)<arr[0].length and c == arr[x][ci+x]
                is_equal<<true
            end
        end
           #p is_equal
        if is_equal.count(true)+1 == arr.length
            return true
        end
        break
    end

    arr.each.with_index do |ele,i|
        arr[i]=ele.reverse
    end
    
    arr[0].each.with_index do |c,ci|
        x=0
        is_equal=[]
        while x<arr.length
            x+=1

            if x<arr.length and (ci+x)<arr[0].length and c == arr[x][ci+x]
                is_equal<<true
            end
        end
           #p is_equal
        if is_equal.count(true)+1 == arr.length
            return true
        end
        break
    end

    return false
end

p squaragonal?([
    [:x, :y, :o],
    [:x, :x, :x],
    [:o, :o, :x],
]) # true

p squaragonal?([
    [:x, :y, :o],
    [:x, :o, :x],
    [:o, :o, :x],
]) # true

p squaragonal?([
    [1, 2, 2, 7],
    [1, 1, 6, 7],
    [0, 5, 1, 7],
    [4, 2, 9, 1],
]) # true

p squaragonal?([
    [1, 2, 2, 5],
    [1, 6, 5, 0],
    [0, 2, 2, 7],
    [5, 2, 9, 7],
]) # false
p "--------------------------------------------"


def pascals_triangle(n)
    tr_arr=[[1]]
    x=2
    while x<=n
        next_row=[]
        (0...x).to_a.each.with_index do |ele,ei|
            next_row<<nil
        end
        tr_arr<<next_row
        x+=1
    end
    tr_arr.each.with_index do |row,ri|
        if row.length ==  1
            next
        end
        
        row.each.with_index do |item,ii|
            left = tr_arr[ri-1][ii-1]
            right = tr_arr[ri-1][ii]

            if ii-1 < 0
                left = 0
            end
            if ii >=  tr_arr[ri-1].length
                right = 0
            end
                row[ii]=left + right
        end
    end
    tr_arr
end

p pascals_triangle(5)
# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1]
# ]

p pascals_triangle(7)
# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1],
#     [1, 5, 10, 10, 5, 1],
#     [1, 6, 15, 20, 15, 6, 1]
# ]