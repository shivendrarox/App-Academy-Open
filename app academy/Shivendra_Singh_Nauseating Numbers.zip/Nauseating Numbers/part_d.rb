def mersenne_prime(n)
    arr=[]
    x=2
    while arr.length != n
        num = 2**x
        if is_prime?(num-1) and num - 1 != 0
            arr<<num-1
        end
        x+=1
    end
    arr[-1]
end

def is_prime?(num)
    (2...num).each do |ele|
        if num%ele == 0
            return false
        end
    end
    return true
end

p mersenne_prime(1) # 3
p mersenne_prime(2) # 7
p mersenne_prime(3) # 31
p mersenne_prime(4) # 127
p mersenne_prime(6) # 131071
p "---------------------------------"

def triangular_word?(word)
    hash=Hash.new()  
    ('a'..'z').to_a.each.with_index do |alphabet,ind|
        hash[alphabet] = ind+1
    end
    sum=0
    word.each_char.with_index do |c,ind|
        sum = sum + hash[c]
    end
    sum

    i=1
    while true
        tnum = (i * (i + 1)) / 2
        if sum == tnum
            return true
        end
        if tnum > sum
            return false
        end
        i+=1
    end
end

p triangular_word?('abc')       # true
p triangular_word?('ba')        # true
p triangular_word?('lovely')    # true
p triangular_word?('question')  # true
p triangular_word?('aa')        # false
p triangular_word?('cd')        # false
p triangular_word?('cat')       # false
p triangular_word?('sink')      # false
p "-----------------------------------------"

def consecutive_collapse(arr)
    consecutive=false
    while !consecutive
        arr.delete(nil)
        arr.each.with_index do |ele,ind|
            left =ind
            right = ind+1
            if arr[left] != nil and arr[right] != nil 
                if arr[left]+1 == arr[right]  or arr[left] == arr[right]+1 
                    arr[left] = nil
                    arr[right] = nil
                    break
                end
            end
        end
        if !arr.include?(nil)
            consecutive =true
        end
    end
    arr
end

 p consecutive_collapse([3, 4, 1])                     # [1]
p consecutive_collapse([1, 4, 3, 7])                  # [1, 7]
 p consecutive_collapse([9, 8, 2])                     # [2]
p consecutive_collapse([9, 8, 4, 5, 6])               # [6]
 p consecutive_collapse([1, 9, 8, 6, 4, 5, 7, 9, 2])   # [1, 9, 2]
 p consecutive_collapse([3, 5, 6, 2, 1])               # [1]
 p consecutive_collapse([5, 7, 9, 9])                  # [5, 7, 9, 9]
 p consecutive_collapse([13, 11, 12, 12])              # []
 p "--------------------------------------"

 
def pretentious_primes(arr,n)
    primes=[]
    arr.each do |ele,i|
        if n>0
            nth=[]
            nth_prime(ele,n).each do |prime_num| 
                if nth.length <= n and prime_num > ele
                    nth<<prime_num
                end
            end
            primes<<nth[-2]
        end
        if n<0
            np = -n
            nth=[]
            less_prime=nth_prime(ele,0).select{|x| x<ele}
            less_prime.reverse!
            
            primes<<less_prime[np-1]
        end
    end
    primes
end

def nth_prime(num,n)
    arr=[]
    x=2
    while true
        if is_prime?(x)
            arr<<x
        end
        if arr.length == num + n
            break
        end
        x+=1
    end
    arr
end
p pretentious_primes([4, 15, 7], 1)           # [5, 17, 11]
p pretentious_primes([4, 15, 7], 2)           # [7, 19, 13]
 p pretentious_primes([12, 11, 14, 15, 7], 1)  # [13, 13, 17, 17, 11]
 p pretentious_primes([12, 11, 14, 15, 7], 3)  # [19, 19, 23, 23, 17]
 p pretentious_primes([4, 15, 7], -1)          # [3, 13, 5]
 p pretentious_primes([4, 15, 7], -2)          # [2, 11, 3]
 p pretentious_primes([2, 11, 21], -1)         # [nil, 7, 19]
 p pretentious_primes([32, 5, 11], -3)         # [23, nil, 3]
 p pretentious_primes([32, 5, 11], -4)         # [19, nil, 2]
 p pretentious_primes([32, 5, 11], -5)         # [17, nil, nil]

