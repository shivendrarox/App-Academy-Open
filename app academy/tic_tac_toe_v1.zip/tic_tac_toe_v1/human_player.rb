class HumanPlayer
    def initialize(mark_value)
        @mark = mark_value
    end

    def mark
        @mark
    end

    def get_position
        x=""
        while true
            puts "Player "+mark.to_s+", Pls enter a position in this format Number<space>Number"
            x=gets.chomp
            #p x
            if x.match?(/\A\d*\s\d*\z/)
                break
            else
                raise "Incorrect format :-(,pls enter again"
            end
        end
        arr=[]
        x.split(' ').each do |ele|
            arr<<ele.to_i
        end
        return arr
    end
end