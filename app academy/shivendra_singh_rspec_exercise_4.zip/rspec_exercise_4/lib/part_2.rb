def proper_factors(num)
    n_arr=[]
    (1...num).each do |d|
        if num%d == 0
            n_arr<<d
        end
    end
    n_arr
end

def aliquot_sum(num)
    proper_factors(num).sum
end

def perfect_number?(num)
    if aliquot_sum(num) == num
        return true
    else
        return false
    end
end

def ideal_numbers(n)
    n_arr=[]
    x=1
    while true 
        if n_arr.length == n
            break
        end
        if perfect_number?(x)
            n_arr<<x
        end
        x+=1
    end
    n_arr
end