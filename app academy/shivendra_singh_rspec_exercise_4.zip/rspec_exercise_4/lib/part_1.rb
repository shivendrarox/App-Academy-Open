def my_reject(arr,&prc)
    n_arr=[]
    arr.map.with_index do |ele,i|
      if prc.call(ele)==false
        n_arr<<ele
      end
    end
    n_arr
end

def my_one?(arr,&prc)
    n_arr=[]
    arr.each do |ele|
        n_arr<<prc.call(ele)
    end
    if n_arr.count(true) == 1
        return true
    else
        return false
    end
end

def hash_select(hash,&prc)
    hash.each_pair do |k,v|
        if prc.call(k,v)== false
            hash.delete(k)
        end
    end
    hash
end

def xor_select(arr,prc1,prc2)
    n_arr=[]
    arr.each do |ele|
        if prc1.call(ele) and prc2.call(ele)
            next
        elsif (prc1.call(ele) and !prc2.call(ele)) or (!prc1.call(ele) and prc2.call(ele))
            n_arr<<ele
        end
    end
    n_arr
end

def proc_count(val,arr)
    n=0
    arr.each do |ele|
        if ele.call(val) == true
            n+=1
        end
    end
    n
end