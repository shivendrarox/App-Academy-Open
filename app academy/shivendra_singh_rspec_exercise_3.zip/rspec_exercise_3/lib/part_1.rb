def is_prime?(num)
    if num<2
            return false
    end
    flag=true
    (2...num).each do |ele|
            if num%ele==0
                flag = false
            end
    end
    return flag
end


def nth_prime(n)
    if !n.instance_of?(Integer)
        raise "improper args"
    end
    x=2
    arr=[]
    found=false
    while !found
        if arr.length ==  n
            found=true
            break
        end
        if is_prime?(x)
            arr<<x
        end
        x+=1
    end
    
    arr[-1]
end

def prime_range(min,max)
    arr=[]
    (min..max).to_a.each do |ele|
        if is_prime?(ele)
            arr<<ele
        end
    end
    arr
end