def element_count(arr)
    hash=Hash.new()
    arr.each do |ele|
        hash[ele]=arr.count(ele)
    end
    hash
end

def char_replace!(str,hash)
    str.chars.each.with_index do |chr,ind|
        if hash.key?(chr)
            str[ind] = hash[chr]
        end
    end
    str
end

def product_inject(arr)
    prod=arr.inject {|pr,n| pr*n}
    prod
end