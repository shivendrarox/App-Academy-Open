def all_words_capitalized?(arr)
    if !arr.instance_of?(Array)
        raise "improper args"
    end

    arr.all?{|a| a==a.capitalize}
end

#p all_words_capitalized?(["Hello", "World"])

def no_valid_url?(arr)
    if !arr.instance_of?(Array)
        raise "improper args"
    end
    invalid_url=['.com', '.net', '.io','.org']
    
    arr.none?{|a| a.end_with?('.com', '.net', '.io','.org')}

end
#p no_valid_url?(["appacademy.biz", "awebsite.me"])

def any_passing_students?(arr)
    if !arr.instance_of?(Array)
        raise "improper args"
    end

    arr.any?{ |a| (a[:grades].sum/a[:grades].length)>=75}
end

students_2 = [
    { name: "Alice", grades: [94, 96] },
    { name: "Bob", grades: [50, 60] }
  ]

p any_passing_students?(students_2)