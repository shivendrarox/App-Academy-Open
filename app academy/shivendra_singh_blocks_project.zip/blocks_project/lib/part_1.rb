def   select_even_nums(arr)
    if ! arr.instance_of?(Array)
        raise "improper args"
    end

    arr.select(&:even?)
end

p select_even_nums([7, 3, 2, 5, 12])

def reject_puppies(arr)
    if ! arr.instance_of?(Array)
        raise "Improper args"
    end
   return arr.reject{|h| h["age"]<=2}
end
dogs = [
        {"name"=>"Fido", "age"=>3},
        {"name"=>"Spot", "age"=>2},
        {"name"=>"Rex", "age"=>5},
        {"name"=>"Gizmo", "age"=>1}
      ]
p reject_puppies(dogs)

def count_positive_subarrays(arr)
    if !arr.instance_of?(Array)
        raise "improper args"
    end

    arr.count{|x|x.sum>0}
end

def aba_translate(word)
    if !word.instance_of?(String)
        raise "improper args"
    end

    word=word.chars
   return word.map{|w|
        if "aeiou".include?(w)
            w=w+"b"+w
        end
        w
    }.join
end

p aba_translate("kite")

def aba_array(arr)
    if !arr.instance_of?(Array)
        raise "improper args"
    end
    arr.map{|x|
    x=aba_translate(x)
    }
end