# Monkey-Patch Ruby's existing Array class to add your own custom methods
require 'byebug'
class Array
    def span
        if self==[]
            return nil
        end
        mm=[]
        mm=self.minmax
        return mm[1]-mm[0]
    end

    def average
        if self==[]
            return nil
        end

        return (self.sum/self.length.to_f)
    end

    def median
        if self==[]
            return nil
        end
        self.sort!
        if self.length.odd?
            return self[(self.length/2)]
        else
            avg=(self[(self.length/2)-1]+self[self.length/2]).to_f/2
            return avg
        end
    end

    def counts
        hash=Hash.new()
        self.each{|ele| hash[ele]=hash[ele].to_i+1}
        return hash
    end

    def my_count(val)
        hash=counts
        if !hash.has_key?(val)
            return 0
        end
        return hash[val]
    end

    def my_index(val)
        hash=counts
        if !hash.has_key?(val)
            return nil
        end
        self.each_with_index{|ele,i| 
            if ele==val
                return i
            end
        }
    end

    def my_uniq
        hash=counts
        return hash.keys
    end

    def my_transpose
      
            n_arr=[]
                self.each_with_index do |ele1,i1|
                    shit=[]
                        ele1.each_with_index do |ele2,i2|
                            shit<<nil
                        end
                        n_arr<<shit
                    end
                    
                self.each_with_index do |ele1,i1|
                    ele1.each_with_index do |ele2,i2|
                    n_arr[i1][i2]=self[i2][i1]
                    end
                end
                return n_arr
    end
end

arr_1 = [
          ["a", "b", "c"],
          ["d", "e", "f"],
          ["g", "h", "i"]
        ]
#debugger
p arr_1.my_transpose