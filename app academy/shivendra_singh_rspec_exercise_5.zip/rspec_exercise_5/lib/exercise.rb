def zip(*arrays)
    arrays.transpose
end

def prizz_proc(arr,prc1,prc2)
    n_arr=[]
    arr.each do |ele|
        if (prc1.call(ele) and !prc2.call(ele)) or (!prc1.call(ele) and prc2.call(ele))
            n_arr<<ele
        end
    end
    n_arr
end

def zany_zip(*arrays)
    max_l =  arrays.max {|a,b|a.length <=> b.length}.length
    arrays.each.with_index do |ele , i|
        if max_l > ele.length
            times= max_l - ele.length
            while times != 0
                arrays[i]<<nil
                times = times -1
            end
        end
    end
    arrays.transpose
end

def maximum(arr,&prc)
    if arr == []
        return nil
    end
    n_arr=[]
    arr.each do |ele|
       n_arr << prc.call(ele)
    end
    
    max_val = n_arr.max {|a,b| a <=> b }
    if n_arr.count > 1
        return     arr.at(n_arr.rindex(max_val))
    end
    arr.at(n_arr.index(max_val))
    
end

def my_group_by(arr, &prc)
    hash = Hash.new()
    arr.each do |ele|
        hash[prc.call(ele)]=[]
    end
    arr.each do |ele|
        hash[prc.call(ele)]<<ele
    end
    hash
end

def max_tie_breaker(arr,blk,&prc)
    if arr == []
        return nil
    end
    n_arr=[]
    arr.each do |ele|
        n_arr<<blk.call(ele)
    end
    p arr
    p n_arr
    max_val = n_arr.max {|a,b| a <=> b}
    p max_val
    if n_arr != n_arr.uniq
        n_arr=[]
        arr.each do |ele|
            n_arr<<prc.call(ele)
        end
        p "tie found"
        p n_arr
        max_val = n_arr.max {|a,b| a <=> b}
        p max_val
        arr.at(n_arr.index(max_val))
    end
    p arr.at(n_arr.index(max_val))

end
def silly_syllables(str)
    str_arr=str.split
    str_arr.each.with_index do |ele,i|
       str_arr[i] = process_word(ele)
    end
    return str_arr.join(" ")
end

def process_word(word)
    vowel = ["a","e","i","o","u"]
    if word.count("\\aeiou") < 2
        return word
    end
    v_ind=[]
    word.each_char.with_index do |ele,i|
        if ele.match?(/[aeiou]/)
            v_ind<<i
        end
    end
    
    p  v_ind

    p word[v_ind[0]..v_ind[-1]]
end