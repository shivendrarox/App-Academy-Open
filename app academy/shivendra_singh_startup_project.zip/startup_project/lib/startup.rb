require "employee"

class Startup
    def initialize(name,funding,salaries)
        @name=name
        @funding=funding
        @salaries=salaries
        @employees=[]
    end

    def name
        @name
    end

    def funding
        @funding
    end

    def funding=(num)
        @funding=num
    end

    def salaries
        @salaries
    end

    def salaries=(hash)
        @salaries=hash
    end

    def employees
        @employees
    end

    def employees=(arr)
        @employees=arr
    end

    def valid_title?(title)
        if @salaries.include?(title)
            return true
        else
            return false
        end
    end

    def >(another_startup)
        if self.funding>another_startup.funding
            return true
        else
            return false
        end
    end

    def hire(employee_name,title)
        if self.valid_title?(title)
            @employees<<Employee.new(employee_name,title)
        else
            raise 'hire error'
        end
    end

    def size
        @employees.length
    end

    def pay_employee(emp)
        if (self.salaries[emp.title])<self.funding
            emp.pay(self.salaries[emp.title])
            self.funding=(self.funding-self.salaries[emp.title])
        else
            raise "error at pay_employees"
        end
    end

    def payday
        self.employees.each do |name|
            self.pay_employee(name)
        end
    end

    def average_salary
        total_sal=0
        self.employees.each do |emp|
            total_sal+=self.salaries[emp.title]
        end

      return  (total_sal/self.employees.length)
    end

    def close
        self.employees=[]
        self.funding=0
    end

    def acquire(another_startup)
        self.funding=self.funding+another_startup.funding
        self.salaries=self.salaries.merge(another_startup.salaries){|key, oldval, newval|
             if !(self.salaries.has_key?(key))
                oldval=newval
             else
                oldval=oldval
             end
            }
        
        self.employees=self.employees+another_startup.employees
        another_startup.close

    end
end
