def duos(str)
  
    if str.chars.length == str.chars.uniq.length
        return 0
    end

    return str.length - str.chars.uniq.length
end

p duos('bootcamp')      # 1
p duos('wxxyzz')        # 2
p duos('hoooraay')      # 3
p duos('dinosaurs')     # 0
p duos('e')             # 0
p "------------------------"

def sentence_swap(str,hash)
    str=str.split(' ')
    str.each.with_index do |word,word_index|
        if hash.key?(word)
            str[word_index] = hash[word]
        end
    end
    str.join(' ')
end

p sentence_swap('anything you can do I can do',
    'anything'=>'nothing', 'do'=>'drink', 'can'=>'shall'
) # 'nothing you shall drink I shall drink'

p sentence_swap('what a sad ad',
    'cat'=>'dog', 'sad'=>'happy', 'what'=>'make'
) # 'make a happy ad'

p sentence_swap('keep coding okay',
    'coding'=>'running', 'kay'=>'pen'
) # 'keep running okay'
p "-------------------------------"

def hash_mapped(hash,proc,&block)
    hsh = {}

    hash.each_pair do |k,v|
        hsh[block.call(k)] = proc.call(v)
    end
    hsh
end

double = Proc.new { |n| n * 2 }
p hash_mapped({'a'=>4, 'x'=>7, 'c'=>-3}, double) { |k| k.upcase + '!!' }
# {"A!!"=>8, "X!!"=>14, "C!!"=>-6}

first = Proc.new { |a| a[0] }
p hash_mapped({-5=>['q', 'r', 's'], 6=>['w', 'x']}, first) { |n| n * n }
# {25=>"q", 36=>"w"}
p "--------------------"

def counted_characters(str)
    str = str.chars
    n_arr = []
    str.uniq.each do |ele|
        if str.count(ele) > 2
            n_arr << ele
        end
    end
    n_arr
end

p counted_characters("that's alright folks") # ["t"]
p counted_characters("mississippi") # ["i", "s"]
p counted_characters("hot potato soup please") # ["o", "t", " ", "p"]
p counted_characters("runtime") # []
p "---------------------------------"

def triplet_true(str)
    str = str.chars

    str.each.with_index do |ele,ind|
        if str[ind] == str[ind+1] and str[ind+1] == str[ind+2]
            return true
        end
    end
    false
end
p triplet_true('caaabb')        # true
p triplet_true('terrrrrible')   # true
p triplet_true('runninggg')     # true
p triplet_true('bootcamp')      # false
p triplet_true('e')             # false
p "-------------------------"

def energetic_encoding(str,hash)
    str=str.chars

    str.each.with_index do |ele,ind|
        if hash.key?(ele)
            str[ind] = hash[ele]
        elsif !hash.key(ele) and ele != ' '
            str[ind] = '?'
        end
    end
    str.join
end

p energetic_encoding('sent sea',
    'e'=>'i', 's'=>'z', 'n'=>'m', 't'=>'p', 'a'=>'u'
) # 'zimp ziu'

p energetic_encoding('cat',
    'a'=>'o', 'c'=>'k'
) # 'ko?'

p energetic_encoding('hello world',
    'o'=>'i', 'l'=>'r', 'e'=>'a'
) # '?arri ?i?r?'

p energetic_encoding('bike', {}) # '????'
p "-----------------------------------------"

def uncompress(str)
    str=str.chars
    n_arr = []
    str.each.with_index do |ele,ind|
        if  ind.odd?
            n_arr<<str[ind-1]*ele.to_i
        end
    end
   p n_arr.join
end

uncompress('a2b4c1') # 'aabbbbc'
uncompress('b1o2t1') # 'boot'
uncompress('x3y1x2z4') # 'xxxyxxzzzz'