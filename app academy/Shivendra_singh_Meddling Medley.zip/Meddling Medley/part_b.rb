def conjunct_select(arr,*prc)
    n_arr=[]
    arr.each.with_index do |ele,ind|
        flag=true
        prc.each.with_index do |procies,pind|
            if !procies.call(ele)
                flag = false
                break
            end
        end
        if flag
            n_arr<<ele
        end
    end
    n_arr
end

is_positive = Proc.new { |n| n > 0 }
is_odd = Proc.new { |n| n.odd? }
less_than_ten = Proc.new { |n| n < 10 }

p conjunct_select([4, 8, -2, 11, 7, -3, 13], is_positive) # [4, 8, 11, 7, 13]
p conjunct_select([4, 8, -2, 11, 7, -3, 13], is_positive, is_odd) # [11, 7, 13]
p conjunct_select([4, 8, -2, 11, 7, -3, 13], is_positive, is_odd, less_than_ten) # [7]
p "------------------------------------"

def convert_pig_latin(str)
    str = str.split(' ')
    str.each.with_index do |word,wind|
        
        if word.length < 3
            next
        end

        first_char_upcase=false
            if word[0] == word[0].upcase 
                first_char_upcase = true
            end

        if word[0].downcase.match?(/[aeiou]/)
            word << "yay"
            
        end
        if !word[0].downcase.match?(/[aeiou]/)
            w_ind=0
            word.each_char.with_index do |w,wi|
                if w.match?(/[aeiou]/)
                    w_ind = wi
                    break
                end
            end
            new_word =  word[w_ind..-1]+ word[0...w_ind] + "ay"
            str[wind] = new_word
        end 
        if first_char_upcase
            #p 'in block'
           str[wind].capitalize!
        end
    end
    str.join(' ')
end

p convert_pig_latin('We like to eat bananas') # "We ikelay to eatyay ananasbay"
p convert_pig_latin('I cannot find the trash') # "I annotcay indfay ethay ashtray"
p convert_pig_latin('What an interesting problem') # "Atwhay an interestingyay oblempray"
p convert_pig_latin('Her family flew to France') # "Erhay amilyfay ewflay to Ancefray"
p convert_pig_latin('Our family flew to France') # "Ouryay amilyfay ewflay to Ancefray"
p "---------------------------------"

def reverberate(str)
    str = str.split(' ')
    str.each.with_index do |word,wind|
        
        if word.length < 3
            next
        end

        first_char_upcase=false
            if word[0] == word[0].upcase 
                first_char_upcase = true
            end

        if word[-1].downcase.match?(/[aeiou]/)
            word << word
            
        end
        if !word[-1].downcase.match?(/[aeiou]/)
            w_ind=0
            w_ind_arr=[]
            word.chars.each.with_index do |w,wi|
                if w.match?(/[aeiou]/)
                    w_ind_arr << wi
                    
                end
            end
            w_ind = w_ind_arr[-1]
            new_word =  word[0..-1]+ word[w_ind..-1]
            str[wind] = new_word
        end 
        if first_char_upcase
            #p 'in block'
           str[wind].capitalize!
        end
    end
    str.join(' ')
end

p reverberate('We like to go running fast') # "We likelike to go runninging fastast"
p reverberate('He cannot find the trash') # "He cannotot findind thethe trashash"
p reverberate('Pasta is my favorite dish') # "Pastapasta is my favoritefavorite dishish"
p reverberate('Her family flew to France') # "Herer familyily flewew to Francefrance"
p "--------------------------------"

def disjunct_select(arr,*prc)
    n_arr = []

    arr.each do |ele|
        prc.each do |procies|
            if procies.call(ele)
                n_arr<<ele
                break
            end
        end
    end
    n_arr
end

longer_four = Proc.new { |s| s.length > 4 }
contains_o = Proc.new { |s| s.include?('o') }
starts_a = Proc.new { |s| s[0] == 'a' }

p disjunct_select(['ace', 'dog', 'apple', 'teeming', 'boot', 'zip'],
    longer_four,
) # ["apple", "teeming"]

p disjunct_select(['ace', 'dog', 'apple', 'teeming', 'boot', 'zip'],
    longer_four,
    contains_o
) # ["dog", "apple", "teeming", "boot"]

p disjunct_select(['ace', 'dog', 'apple', 'teeming', 'boot', 'zip'],
    longer_four,
    contains_o,
    starts_a
) # ["ace", "dog", "apple", "teeming", "boot"]
p "-----------------------"


def alternating_vowel(str)
    str = str.split(' ')
    str.each.with_index do |word,wind|
        v_arr=[]
        word.chars.each.with_index do |w,wi|
            if w.match?(/[aeiou]/)
                v_arr<<wi
            end
        end
        word=word.chars
        if wind.even? and v_arr.length>=1
            word.delete_at(v_arr[0])
        elsif !wind.even? and v_arr.length>=1
            word.delete_at(v_arr[-1])
        end

        word = word.join
        str[wind] = word
    end
    str.join(' ')
end

p alternating_vowel('panthers are great animals') # "pnthers ar grat animls"
p alternating_vowel('running panthers are epic') # "rnning panthrs re epc"
p alternating_vowel('code properly please') # "cde proprly plase"
p alternating_vowel('my forecast predicts rain today') # "my forecst prdicts ran tday"
p '------------------------------------------------------'

def silly_talk(str)
        str = str.split(' ')
    str.each.with_index do |word,wind|
        
        if word.length < 3
            next
        end

        first_char_upcase=false
            if word[0] == word[0].upcase 
                first_char_upcase = true
            end

        if word[-1].downcase.match?(/[aeiou]/)
            word << word[-1]
            
        end
        if !word[-1].downcase.match?(/[aeiou]/)
            w_ind=0
            w_ind_arr=[]
            word.chars.each.with_index do |w,wi|
                if w.match?(/[aeiou]/)
                    w_ind_arr << wi
                    
                end
            end
            word=word.chars
            w_ind_arr.each do |x|
                word[x] = word[x] + 'b' + word[x]
            end
            new_word =  word.join
            str[wind] = new_word
        end 
        if first_char_upcase
            #p 'in block'
           str[wind].capitalize!
        end
    end
    str.join(' ')
end

p silly_talk('Kids like cats and dogs') # "Kibids likee cabats aband dobogs"
p silly_talk('Stop that scooter') # "Stobop thabat scobooboteber"
p silly_talk('They can code') # "Thebey caban codee"
p silly_talk('He flew to Italy') # "Hee flebew too Ibitabaly"
p '---------------------'

def compress(str)
    str=str.chars
    n_arr=[1]
    n_str=[]
    str.each.with_index do |s,si|
        if str[si] == str[si-1]
            n_arr[-1]+=1
        else
            if n_arr[-1] == 1
                n_str<<str[si-1]
            else
                n_str<<str[si-1]+n_arr[-1].to_s
            end
            n_arr<<1
        end
    end
    sentence=n_str[1..-1].join
    sentence<<n_str[0]
    if n_arr[-1] !=1
        return sentence<<n_arr[-1].to_s
    end
    sentence
end
p compress('aabbbbc')   # "a2b4c"
p compress('boot')      # "bo2t"
p compress('xxxyxxzzzz')# "x3yx2z4"