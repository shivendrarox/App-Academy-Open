class Item
    def self.valid_date?(date_string)
        arr=date_string.split('-')
        year = false
        month = false
        day=false
        if arr[0].match?(/\A\d{4}\z/)
            year = true
        else
            return false
        end

        if arr[1].match?(/\A\d{2}\z/) and arr[1].to_i <= 12 and arr[1].to_i >=1
            month = true
        else
            return false
        end

        if arr[2].match?(/\A\d{2}\z/) and arr[2].to_i <= 31 and arr[2].to_i >=1
            day = true
        else
            return false
        end
        return true
    end

    def initialize(title,deadline,description)
        @done = false
        @title = title
        @deadline=deadline
        if !Item.valid_date?(@deadline)
            raise "incorrect deadline"
        end
        @description = description
    end

    def done
        @done
    end

    def title
        @title        
    end

    def title=(new_title)
        @title = new_title
    end

    def deadline
        @deadline
    end

    def deadline=(new_deadline)
        if Item.valid_date?(new_deadline)
            @deadline = new_deadline
        else
            raise "incorrect deadline"
        end
    end

    def description
        @description
    end

    def description=(new_description)
        @description = new_description
    end

    def toggle
        if @done == false
            @done = true
        else
            @done = false
        end
    end
end