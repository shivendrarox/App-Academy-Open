require_relative 'item.rb'
require_relative 'list.rb'

class TodoBoard
    def initialize#(label)
        @list_hash={}
        #@label = label
        #@list = List.new(@label)
    end

    def get_command
        print "\nEnter a command: "
        cmd, *args = gets.chomp.split(' ')

        case cmd
        when 'mktodo'
            @list_hash[args[0]].add_item(args[1],args[2],args[3])
        when 'ls'
            @list_hash.keys.each{|ele| puts ele}
        when 'showall'
            @list_hash.values.each{|ele| ele.print}
        when 'mklist'
            @list_hash[*args[0]] = List.new(*args[0])
        when 'up'
            @list_hash[args[0]].up(args[1],args[2])
        when 'down'
            @list_hash[args[0]].down(args[1],args[2])
        when 'swap'
            @list_hash[args[0]].swap(args[1],args[2])
        when 'sort'
            @list_hash[args[0]].sort_by_date!
        when 'priority'
            @list_hash[args[0]].print_priority
        when 'toggle'
            @list_hash[args[0]].toggle_item(args[1].to_i)
        when 'rm'
            @list_hash[args[0]].remove_item(args[1].to_i)
        when 'purge'
            @list_hash[args[0]].purge
        when 'print'
            if args.length == 1
                @list_hash[args[0]].print
            else
                @list_hash[args[0]].print_full_item(args[1].to_i)
            end
        when 'quit'
            return false
        else
            print "Sorry, that command is not recognized."
        end

        true
    end

    def run
        while true
            if get_command == false
                break
            end
        end
    end
end

new_todo_board = TodoBoard.new()
new_todo_board.run