require_relative 'item.rb'
class List
    def initialize(label)
        @items = []
        @label = label
    end

    def label
        @label
    end

    def label=(new_label)
        @label = new_label
    end

    def add_item(title,deadline,description="")
        if !Item.valid_date?(deadline)
            return false
        end
        new_item = Item.new(title,deadline,description)
        @items<<new_item
        return true
    end

    def size()
        @items.length
    end

    def valid_index?(index)
        if index<0
            return false
        elsif index >= @items.length
            return false
        end
        return true
    end

    def swap(index_1,index_2)
        index_1=index_1.to_i
        index_2 = index_2.to_i
        if !valid_index?(index_1) or !valid_index?(index_2)
            return false
        end
        @items[index_1],@items[index_2] = @items[index_2],@items[index_1]
        true
    end

    def [](index)
        if !valid_index?(index) 
            return nil
        end
        @items[index]
    end

    def priority
        @items[0]
    end

    def print
        puts "-------------------"
        puts label.ljust(4)
        puts "-------------------"
        @items.each.with_index do |ele,i|
            puts i.to_s+"   |"+ele.title.ljust(4)+"   |"+ele.deadline+"  | ["+ele.done.to_s+"]"
        end
        nil
    end

    def print_full_item(index)
        if !valid_index?(index)
            return
        end
        puts "------------------------"
        puts @items[index].title
        puts @items[index].deadline
        puts @items[index].description
        puts @items[index].done
        puts "-------------------------"
    end

    def print_priority
        print_full_item(0)
    end

    def up(index,ammount=1)
        index = index.to_i
        if ammount != ammount.to_i
            ammount=ammount.to_i
        end
        og_index = index.to_i
        if !valid_index?(index)
            return false
        end
        while ammount!=0
            if index == 0
                break
            end
            @items[index],@items[index-1] = @items[index-1],@items[index]
            index-=1
            ammount = ammount - 1
        end
        return true
    end

    def down(index,ammount=1)
        index = index.to_i
        if ammount != ammount.to_i
            ammount=ammount.to_i
        end
        og_index = index.to_i
        if !valid_index?(index)
            return false
        end
        while ammount != 0
            if index == @items.length-1
                break
            end
            @items[index],@items[index+1] = @items[index+1],@items[index]
            index=index+1
            ammount = ammount - 1
        end
        return true
    end

    def sort_by_date!()
        @items.sort_by!{|a| a.deadline}
    end

    def toggle_item(index)
        @items[index].toggle
    end

    def remove_item(index)
        if !valid_index?(index)
            return false
        end
        @items.delete_at(index)
        return true
    end

    def purge
        @items.delete_if{|ele| ele.done}
    end

end