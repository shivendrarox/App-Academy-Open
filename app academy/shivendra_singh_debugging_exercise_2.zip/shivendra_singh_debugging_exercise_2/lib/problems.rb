# Run `bundle exec rspec` and satisy the specs.
# You should implement your methods in this file.
# Feel free to use the debugger when you get stuck.

def largest_prime_factor(num)
    if ! num.instance_of?(Integer)
        raise "improper args"
    end
    primes=[]
    divs=[]
    (2..num).each do |x|
       divs<<x if num%x==0
    end

    divs.each do |x|
        if isPrime?(x)
            primes<<x
        end
    end

    return primes[-1]
end

def isPrime?(n)
    (2...n).each do |x|
        return false if n%x == 0
    end
    return true
end

#p largest_prime_factor(7)

def unique_chars?(str)
    if ! str.instance_of?(String)
        raise "improper args"
    end

    ch=str.chars
    
    if ch==ch.uniq
        return true
    else
        return false
    end
end

def dupe_indices(arr)
    if !arr.instance_of?(Array)
        raise "impoper args"
    end

    hash=Hash.new()
    
    arr.each do |x|
        hash[x]=[]
    end

    arr.each_with_index do |x,i|
        hash[x].append(i)
    end

    hash.delete_if {|key, value| value.length == 1 } 

    return hash
end

#p dupe_indices(["a", "b", "c", "c", "b"])

def ana_array(arr_1,arr_2)
    if ( !arr_1.instance_of?(Array) and !arr_2.instance_of?(Array))
        raise "improper args"
    end

    hash_1=Hash.new()
    hash_2=Hash.new()

    arr_1.each do |x|
        hash_1[x]=true
    end

    arr_2.each do |x|
        hash_2[x]=true
    end

    if hash_1==hash_2 and arr_1.length==arr_2.length
        return true
    else
        return false
    end

end

p ana_array(["i","c","e","m","a","n"], ["c","i","n","e","m","a"])