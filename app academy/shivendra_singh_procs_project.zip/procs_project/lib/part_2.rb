def reverser(str,&prc)
   if !str.instance_of?(String) and !prc.instance_of?(Proc)
    raise "invalid args"
   end
   proc.call(str.reverse!)
end

def word_changer(str,&prc)
    if !str.instance_of?(String) and !prc.instance_of?(Proc)
        raise "invalid args"
    end

    str=str.split(" ")
    n_arr=[]
    str.each{|ele| n_arr<< prc.call(ele)}
    return n_arr.join(" ")
end

def  greater_proc_value(num,prc1,prc2)
    if !prc1.instance_of?(Proc) and !prc2.instance_of?(Proc) and !num.instance_of?(Integer)
        raise "invalid args"
    end

    res1=prc1.call(num)
    res2=prc2.call(num)

    return res1 if res1>res2
    return res2
end

def and_selector(arr,prc1,prc2)
    if !prc1.instance_of?(Proc) and !prc2.instance_of?(Proc) and !arr.instance_of?(Array)
        raise "invalid args"
    end

    n_arr=[]

    arr.each{|ele| n_arr<<ele if prc1.call(ele) and prc2.call(ele)}
    return n_arr
end

def alternating_mapper(arr,prc1,prc2)
    if !prc1.instance_of?(Proc) and !prc2.instance_of?(Proc) and !arr.instance_of?(Array)
        raise "invalid args"
    end

    n_arr=[]

    arr.each_with_index{|ele,i| 
        if i.even?
            n_arr<<prc1.call(ele)
        end
        if i.odd?
            n_arr<<prc2.call(ele)
        end
        
        }

        return n_arr
end