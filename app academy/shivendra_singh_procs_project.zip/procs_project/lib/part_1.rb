def my_map(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end
    n_arr=[]
    arr.each{|ele| n_arr<<prc.call(ele)}
    return n_arr
end

def my_select(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end

    n_arr=[]

    arr.each{|ele| n_arr<<ele if prc.call(ele)}

    return n_arr
end

def my_count(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end

    num=0

    arr.each{|ele| num+=1 if prc.call(ele)}

    return num
end

def my_any?(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end

    isFound=false
    arr.each{|ele|  isFound=true if prc.call(ele)}

    return isFound

end

def my_all?(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end

    isFound=true
    arr.each{|ele|  isFound=false if !prc.call(ele)}

    return isFound

end

def my_none?(arr,&prc)
    if !arr.instance_of?(Array) and !prc.instance_of?(Proc)
        raise "improper args"
    end

    isFound=true
    arr.each{|ele|  isFound=false if prc.call(ele)}

    return isFound


end