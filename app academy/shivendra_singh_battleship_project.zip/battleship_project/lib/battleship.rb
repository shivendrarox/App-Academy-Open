require_relative "board"
require_relative "player"

class Battleship
    def initialize(n)
        @player= Player.new()
        @board=Board.new(n)
        @remaining_misses=@board.size/2
    end

    attr_reader :remaining_misses
    attr_writer :remaining_misses

    def board
        @board
    end

    def player
        @player
    end

    def start_game
        self.board.place_random_ships
        puts self.board.num_ships
         self.board.print
    end

    def lose?()
        if self.remaining_misses <= 0
            puts 'you lose'
            return true
        else
            return false
        end
    end

    def win?()
        if self.board.num_ships==0
            print 'you win'
            return true
        else
            return false
        end
    end

    def game_over?()
        if self.win? or self.lose?
            return true
        else
            return false
        end
    end
    
    def turn
       move= self.player.get_move
        self.board.print
       if self.board.attack(move)
        puts self.remaining_misses

       else
        self.remaining_misses-=1
        puts self.remaining_misses

       end
    end
end
