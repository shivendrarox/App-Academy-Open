class Board
  def initialize(n)
    @grid=Array.new(n) {Array.new(n,:N)}
    @size=n*n
  end

  def grid
    @grid
  end

  def size
    @size
  end

  def [](pos)
    x, y = pos
    @grid[x][y]
  end

  def []=(pos, val)
    x, y = pos
    @grid[x][y] = val
  end
 
  def num_ships
    total=0
    self.grid.each do |row|
        total+=row.count(:S)
    end
   return total
  end
  
  def attack(pos)
    if self.[](pos)!=:S
        self.[]=(pos,:X)
        return false
    else
        self.[]=(pos,:H)
        p 'you sunk my battleship!'
        return true
    end
  end

  def place_random_ships
    grid25=(self.size/4)
    pos=[]
    while grid25!=0
        prng = Random.new
        row=prng.rand(0...Integer.sqrt(self.size))
        column=prng.rand(0...Integer.sqrt(self.size))
        if pos.include?([row,column])
            next
        end
        pos<<[row,column]
        grid25-=1
    end
    pos.each do |ele|
        self.grid[ele[0]][ele[1]]=:S
    end
  end

  def hidden_ships_grid
    x=[]
    x= self.grid.map do |row|
            row.map do |col|
                if col==:S
                    col=:N
                else
                    col
                end
            end
        end
    return x
  end

  def self.print_grid(arr2d)
    str=""
    arr2d.each do |row|
       str<<row.join(' ')
        puts str
        str=''
    end
  end

  def cheat()
    Board.print_grid(self.grid)
  end

  def print
    Board.print_grid(self.hidden_ships_grid)
  end

end
