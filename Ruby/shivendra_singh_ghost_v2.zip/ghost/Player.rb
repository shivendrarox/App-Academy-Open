require_relative "Game.rb"

class Player
	def initialize(name)
		@name=name
	end
	
	def name
		@name
	end

	def guess
		#puts "enter a guess, Player: "+name
		g=gets.chomp
		return g	
	end

	def alert_invalid_guess()
		#if guess.match?(/\A[a-zA-Z]\z/) #and @dictionary.keys.any?{|x| x.include?(@fragment+string)}
		#	return true
		#end		
		puts "invalid guess, player: "+name+", Pls enter again!"
		#return false
	end
end
