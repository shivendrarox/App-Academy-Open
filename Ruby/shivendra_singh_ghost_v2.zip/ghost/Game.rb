require_relative "Player.rb"

class Game
	def initialize(*players)
		@dictionary = {}
		f=File.new("dictionary.txt",chomp: true)
		f.readlines.each{|ele| @dictionary[ele.chomp]=nil}
		#puts @dictionary
		@player = players
		@fragment = ""	
		@losses=Hash.new(0)
		@player.each{|ele| losses[ele]}
	end
	
	def play_round
			take_turn(current_player)
			if @dictionary.keys.any?{|x| x == @fragment }
				#losses[previous_player.name] +=1
				#@player.each do |ele|
				#	if ele.name != current_player.name
						losses[current_player.name] +=1
				#	end
				#end
				#p losses
				display_standings()
				@fragment=""
				player_out()
			end
			next_player!
	end

	def current_player
		@player[0]
	end

	def previous_player
		#@player[1]
		@player[-1]
	end

	def next_player!
		#@player[1],@player[0] = @player[0],@player[1]
		@player<<@player.shift
	end

	def take_turn(player)
		puts "pls enter a alphabet, player: "+player.name
		str = gets.chomp
		while !valid_play?(str)#!current_player.alert_invalid_guess()#
			player.alert_invalid_guess()
			#str = gets.chomp
			str = player.guess
		end

		if valid_play?(str)
			 @fragment<<str
			 p @fragment
		end
	end
	
	def valid_play?(string)
		if string.match?(/\A[a-zA-Z]\z/) and @dictionary.keys.any?{|x| x.start_with?((@fragment+string))}
			return true
		end		
		return false
	end

	def losses
		@losses
	end

	def record(player)
		ghost = "GHOST"
		str=ghost[0...losses[player.name]]
		return str
	end

	def run
		#while !losses.values.any?{|x| x==5}
		while @player.length > 1
			play_round
		end
		#end
		@losses.each_pair do |k,v|
			if v<5
				puts k+" has WON the game!!!"
			end
		end
		return "Game ends"
	end

	def display_standings
		#puts previous_player.name+" lost!!!"
		puts "SCORE :"
		@player.each do |ele|
			if ele.name == current_player.name
				puts ele.name+" lost this match!!!"
			else
				puts ele.name+" won this match!!!"
			end
		end
		#puts current_player.name+" won!!!"		
		#puts current_player.name+" : "+record(current_player)
		@player.each do |ele|
			puts ele.name+" : "+record(ele)
		end
		#puts previous_player.name+" : "+record(previous_player)
		puts "-------------------------------"
	end

	def player_out
		losses.each_pair do |k,v|
			if v == 5
				@player.delete_if{|x| x.name == k}
				puts "GAME OVER PLAYER: "+k+"!!"
			end
		end
		
		puts "Players Remainig: "+@player.length.to_s
	end

end
if $PROGRAM_NAME == __FILE__
	game = Game.new(
	  Player.new("Gizmo"), 
	  Player.new("Breakfast"), 
	  Player.new("Toby"),
	  Player.new("Leonardo")
	  )
  
	game.run
end