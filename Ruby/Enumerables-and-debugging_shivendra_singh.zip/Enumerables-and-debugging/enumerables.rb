require 'byebug'

class Array
    def my_each(&prc)
        x=0
        while x<self.length
            prc.call(self[x])
            x+=1
        end
        return self
    end

    def my_select(&prc)
        arr=[]
        self.my_each do |ele|
            if prc.call(ele)
                arr<<ele
            end
        end
        arr
    end

    def my_reject(&prc)
        arr=[]
        self.my_each do |ele|
            if !prc.call(ele)
                arr<<ele
            end
        end
        arr
    end

    def my_any?(&prc)
        self.my_each do |ele|
            if prc.call(ele)
                return true
            end
        end
        return false
    end

    def my_all?(&prc)
        self.my_each do |ele|
            if !prc.call(ele)
                return false
            end
        end
        return true
    end

    def my_flatten
        #debugger
        arr=[]
        self.my_each do |ele|
            if ele.is_a?(Array)
                arr.concat(ele.my_flatten)
            else
                arr<<ele
            end
        end
       arr
    end

    def my_zip(*arr)
        n_arr=[]
        self.each.with_index do |s_ele,si|
            x=[s_ele]
            arr.each.with_index do |a_ele,ai|
                a_ele.each.with_index do |ele,i|
                    if si == i
                        x<<ele
                    end
                end
            end
            if x.length < self.length
                diff = self.length - x.length
                (0...diff).each do |ele|
                    x<<nil
                end
            end
            n_arr<<x
        end
        n_arr
    end

    def my_rotate(n=1)
        n_arr = Array.new(self)
        if n <0
            p_n = -n
            (1..p_n).to_a.each do |x|
                m=n_arr.pop
                n_arr.unshift(m)
            end
        else
            (1..n).to_a.each do |x|
                m=n_arr.shift
                n_arr<<m
            end
        end
        n_arr
    end

    def my_join(sep='')
        str=""
        self.my_each do |ele|
            str<<ele
            str<<sep
        end
        if sep != ''
            str[-1] = ''
        end
        str
    end

    def my_reverse
        n_arr=[]
        (1..self.length).to_a.my_each do |ele|
            n_arr<<self[-ele]
        end
        n_arr
    end
end